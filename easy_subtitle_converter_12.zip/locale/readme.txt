To edit this files you can use freeware tool named PoEdit, 
which you can get from http://www.poedit.net/download.php

If you want to add a new language just modify any existing
language.

If you want you can send me your translation and I will
add it to new version of this program. Your name will be
mentioned in the about box.

Please note that the program is not Unicode ready, so
non-latin alphabets might not work properly.